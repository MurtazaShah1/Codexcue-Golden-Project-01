def text_to_words(text):
    # Convert text to lowercase and split into words
    words = text.lower().split()
    return words

def calculate_similarity(text1, text2):
    # Convert both texts to sets of words
    words1 = set(text_to_words(text1))
    words2 = set(text_to_words(text2))
    
    # Find the common words
    common_words = words1.intersection(words2)
    
    # Calculate similarity as the ratio of common words to the total unique words
    similarity = len(common_words) / max(len(words1), len(words2))
    
    return similarity * 100

# User input
print("Enter the first text document:")
text1 = input()

print("Enter the second text document:")
text2 = input()

# Calculate similarity
similarity_score = calculate_similarity(text1, text2)

# Display the similarity score
print(f"Similarity score: {similarity_score:.2f}%")
